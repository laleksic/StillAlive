# Exit script if any command fails
set -e

# Print each command as it is run
set -x

# Configures number of jobs for parallel builds
JOBS=4

export CFLAGS=""
export LDFLAGS=""
CMAKE_OPTIONS=""

if [ "$ARCH" = "32" ]
then
    :
elif [ "$ARCH" = "64" ]
then
    :
else
    echo "set the ARCH environment variable to 32 or 64"
    exit 1
fi

CFLAGS+="-m$ARCH "

BUILD_DIR="build_${OS}_$ARCH"
INSTALL_DIR="install_${OS}_$ARCH"
RUNTIME_DIR="runtime_${OS}_$ARCH"

if [ "$OS" = "windows" ]
then
    CMAKE_GENERATOR="MinGW Makefiles"
    LIBRARY_SUFFIX=".dll.a"
    RUNTIME=""
    RUNTIME+="$INSTALL_DIR/bin/*.dll "
    RUNTIME+="/c/mingw$ARCH/bin/libstdc++-6.dll "
    if [ "$ARCH" = "32" ]
    then
        RUNTIME+="/c/mingw$ARCH/bin/libgcc_s_dw2-1.dll "
    elif [ "$ARCH" = "64" ]
    then
        RUNTIME+="/c/mingw$ARCH/bin/libgcc_s_seh-1.dll "
    else
        :
    fi
    RUNTIME+="/c/mingw$ARCH/bin/libwinpthread-1.dll "
    export PATH="$PATH:/c/mingw$ARCH/bin/"
elif [ "$OS" = "linux" ]
then
    CMAKE_GENERATOR="Unix Makefiles"
    LIBRARY_SUFFIX=".so"
    RUNTIME="$INSTALL_DIR/lib/*.so"
    export PATH="~/x-tools/x86_64-centos6-linux-gnu/bin/:$PATH"
    export CC="x86_64-centos6-linux-gnu-gcc"
    export CXX="x86_64-centos6-linux-gnu-g++"
    CFLAGS+="-I`pwd`/include_linux_$ARCH "
    LDFLAGS+="-L`pwd`/link_linux_$ARCH "
    LDFLAGS+="-Wl,-rpath,\$ORIGIN "
    LDFLAGS+="-Wl,-z,origin "
    LDFLAGS+="-static-libstdc++ -static-libgcc "
    CMAKE_OPTIONS+="-DCMAKE_PLATFORM_NO_VERSIONED_SONAME=TRUE "    
    CMAKE_OPTIONS+="-DCMAKE_SYSROOT=$HOME/x-tools/x86_64-centos6-linux-gnu/x86_64-centos6-linux-gnu/sysroot "    
else
    echo "set the OS environment variable to linux or windows"
    exit 1
fi

export CMAKE_PREFIX_PATH=`pwd`/$INSTALL_DIR
CMAKE_OPTIONS+="-DCMAKE_PREFIX_PATH=$INSTALL_DIR "
CMAKE_OPTIONS+="-DCMAKE_VERBOSE_MAKEFILE=TRUE "
CMAKE_OPTIONS+="-DCMAKE_FIND_LIBRARY_SUFFIXES=$LIBRARY_SUFFIX "
CMAKE_OPTIONS+="-DCMAKE_BUILD_TYPE=Release "
CMAKE_OPTIONS+="-DCMAKE_INSTALL_PREFIX=$INSTALL_DIR "
CMAKE_OPTIONS+="-DBUILD_SHARED_LIBS=ON "

export CXXFLAGS=$CFLAGS

LIBRARY_DIR=libogg-1.3.5
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \
    -DBUILD_TESTING=OFF \

cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

LIBRARY_DIR=flac-1.4.3
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \
    -DBUILD_CXXLIBS=OFF \
    -DBUILD_DOCS=OFF \
    -DBUILD_EXAMPLES=OFF \
    -DBUILD_PROGRAMS=OFF \
    -DBUILD_TESTING=OFF \
    -DINSTALL_MANPAGES=OFF \
    
cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

LIBRARY_DIR=libvorbis-1.3.7
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \
    
cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

LIBRARY_DIR=zlib-1.3
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \

cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

LIBRARY_DIR=freetype-2.13.1
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \
    -DFT_DISABLE_BROTLI=ON \
    -DFT_DISABLE_BZIP2=ON \
    -DFT_DISABLE_HARFBUZZ=ON \
    -DFT_DISABLE_PNG=ON \
    
cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

LIBRARY_DIR=openal-svn-mirror-master/OpenAL-Soft
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \
    -DUTILS=ON \

cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

LIBRARY_DIR=SFML-2.5.1
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \
    -DSFML_USE_SYSTEM_DEPS=TRUE \

cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

LIBRARY_DIR=CSFML-2.5.2
cmake \
    -S "sources/$LIBRARY_DIR" \
    -B "$BUILD_DIR/$LIBRARY_DIR" \
    -G "$CMAKE_GENERATOR" \
    $CMAKE_OPTIONS \
    -DCSFML_LINK_SFML_STATICALLY=FALSE \

cmake --build "$BUILD_DIR/$LIBRARY_DIR" --parallel $JOBS
cmake --install "$BUILD_DIR/$LIBRARY_DIR"

mkdir -p $RUNTIME_DIR
rm -f $RUNTIME_DIR/*

cp $RUNTIME $RUNTIME_DIR

if [ "$OS" = "windows" ]
then
    # for some reason it's built as libogg.dll, but the dependant libraries want it to be called ogg.dll at runtime!
    mv $RUNTIME_DIR/libogg.dll $RUNTIME_DIR/ogg.dll
    
    # remove the -2 suffix that gets appended to csfml dll names on windows (again unknown reason)
    mv $RUNTIME_DIR/csfml-audio-2.dll $RUNTIME_DIR/csfml-audio.dll
    mv $RUNTIME_DIR/csfml-graphics-2.dll $RUNTIME_DIR/csfml-graphics.dll
    mv $RUNTIME_DIR/csfml-network-2.dll $RUNTIME_DIR/csfml-network.dll
    mv $RUNTIME_DIR/csfml-system-2.dll $RUNTIME_DIR/csfml-system.dll
    mv $RUNTIME_DIR/csfml-window-2.dll $RUNTIME_DIR/csfml-window.dll
fi
